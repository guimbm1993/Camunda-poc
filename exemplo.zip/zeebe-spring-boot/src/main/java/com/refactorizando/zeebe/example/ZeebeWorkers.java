package com.refactorizando.zeebe.example;

import com.refactorizando.zeebe.example.service.SQSEventPublisher;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import java.time.Instant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.logging.*;

@Component
@Slf4j
public class ZeebeWorkers {

  @Autowired
  private SQSEventPublisher sqsEventPublisher;

  @ZeebeWorker(type = "processa-pedido", name = "inicio-fluxo")
  public void processOrder(final JobClient client, final ActivatedJob job){
    logJob(job);
    Map<String, Object> variablesAsMap = job.getVariablesAsMap();
    if(variablesAsMap.containsKey("destinatario") && variablesAsMap.containsKey("valor")){
      client.newCompleteCommand(job.getKey()).variables("{\"pedidoValido\": true}").send().join();
    }else{
      client.newCompleteCommand(job.getKey()).variables("{\"pedidoValido\": false}").send().join();
    }
  }

  @ZeebeWorker(type = "analise-pedido", name = "analise-fraude")
  public void analyze(final JobClient client, final ActivatedJob job){
    logJob(job);
    Map<String, Object> variablesAsMap = job.getVariablesAsMap();
    if(variablesAsMap.containsKey("pedidoValido")){
      Object pedidoValido = variablesAsMap.get("pedidoValido");
      if(pedidoValido.equals(Boolean.TRUE)){
        client.newCompleteCommand(job.getKey()).variables("{\"fraude\": \"Não\"}").send().join();
      }else{
        client.newCompleteCommand(job.getKey()).variables("{\"fraude\": \"Sim\"}").send().join();
      }
    }else{
      client.newCompleteCommand(job.getKey()).variables("{\"fraude\": \"Sim\"}").send().join();
    }
  }


  @ZeebeWorker(type = "executar-bloqueio", name = "executar-bloqueio")
  public void block(final JobClient client, final ActivatedJob job){
    logJob(job);
    Map<String, Object> variablesAsMap = job.getVariablesAsMap();
    if(variablesAsMap.containsKey("fraude")){
      Object fraude = variablesAsMap.get("fraude");
      String response = fraude.toString();
      if(response.equalsIgnoreCase("Sim")){
        sqsEventPublisher.publishEvent("{\"bloqueio\": true, \"cc\": \"12345\"}");
      }
      client.newCompleteCommand(job.getKey()).send().join();
    }else{
      logJob(job);
      client.newCompleteCommand(job.getKey()).send().join();
    }
  }

  @ZeebeWorker(type = "comunica-cliente", name = "comunica-cliente")
  public void sendComunication(final JobClient client, final ActivatedJob job){
    logJob(job);
    Map<String, Object> variablesAsMap = job.getVariablesAsMap();
    if(variablesAsMap.containsKey("fraude")){
      Object fraude = variablesAsMap.get("fraude");
      String response = fraude.toString();
      if(response.equalsIgnoreCase("Sim")){
        sqsEventPublisher.publishEvent("{\"mensagem\": \"foi feita uma transação...\", \"cc\": \"12345\"}");
      }
      client.newCompleteCommand(job.getKey()).send().join();
    }else{
      logJob(job);
      client.newCompleteCommand(job.getKey()).send().join();
    }
  }

  @ZeebeWorker(type = "classify", name = "main-worker")
  public void classifyEmergency(final JobClient client, final ActivatedJob job) {
    logJob(job);
    if (job.getVariablesAsMap().get("alertReason")
        == null) {
      client.newCompleteCommand(job.getKey()).variables("{\"alertType\": \"injured\"}").send()
          .join();
    } else if (job.getVariablesAsMap().get("alertReason").toString().contains("injured")) {
      client.newCompleteCommand(job.getKey()).variables("{\"alertType\": \"injured\"}").send()
          .join();
    } else if (job.getVariablesAsMap().get("alertReason").toString().contains("thieve")) {
      client.newCompleteCommand(job.getKey()).variables("{\"alertType\": \"robbery\"}").send()
          .join();
    }
  }

  @ZeebeWorker(type = "hospital", name = "main-worker")
  public void hospitalCoordination(final JobClient client, final ActivatedJob job) {
    logJob(job);
    client.newCompleteCommand(job.getKey()).send().join();
  }

  @ZeebeWorker(type = "prison", name = "main-worker")
  public void prisonCoordination(final JobClient client, final ActivatedJob job) {
    logJob(job);
    client.newCompleteCommand(job.getKey()).send().join();
  }

  private static void logJob(final ActivatedJob job) {
    log.info(
        "complete job\n>>> [type: {}, key: {}, element: {}, workflow instance: {}]\n{deadline; {}]\n[headers: {}]\n[variables: {}]",
        job.getType(),
        job.getKey(),
        job.getElementId(),
        job.getProcessInstanceKey(),
        Instant.ofEpochMilli(job.getDeadline()),
        job.getCustomHeaders(),
        job.getVariables());
  }

}
