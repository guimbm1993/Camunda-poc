package com.refactorizando.zeebe.example;

import io.camunda.zeebe.spring.client.EnableZeebeClient;
import io.camunda.zeebe.spring.client.annotation.Deployment;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableZeebeClient
@Deployment(resources = {"classpath:alert-process.bpmn","classpath:fraudes.bpmn"})
public class AlertSystem {

  public static void main(String[] args) {
    SpringApplication.run(AlertSystem.class, args);
  }


}
